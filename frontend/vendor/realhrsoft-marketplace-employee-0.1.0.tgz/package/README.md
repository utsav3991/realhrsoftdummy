# RealHRSoft Marketplace: employee screens for Vue 3 + Vuetify 3

This package contains the Marketplace screens RealHRSoft employees use inside the RealHRSoft
web app:

- **Discover:** browse offers from businesses and claim them.
- **Company benefits:** benefits from the employee's company or group, and when they used them.
- **My offers:** claims and requests, each with its voucher and a time-limited QR code to show
  at the business.
- **My vouchers.**
- **Notifications:** a full inbox, plus a bell for your app bar.
- **Sponsored placements:** clearly labelled advertisements and their pages.

It is a Vue plugin plus route records. Your app keeps its own layout, navigation, login and
company switcher; the screens render inside it.

Requirements: Vue 3.5+, Vue Router 4, Vuetify 3.7+, and the Material Design Icons font
(`@mdi/font`), which Vuetify uses by default.

## 1. Install and mount

```ts
import { createApp, ref } from "vue";
import { createMarketplace, marketplaceRoutes } from "@realhrsoft/marketplace-employee";
import "@realhrsoft/marketplace-employee/style.css"; // the screens' own small stylesheet

// The company the employee acts for: a RealHRSoft company UUID from your session.
const companyId = ref<string | null>(currentCompanyUuid);

app.use(vuetify).use(router).use(
  createMarketplace({
    baseUrl: "/api/marketplace", // your backend proxy (section 2)
    companyId, // a ref or getter; changing it reloads every screen
    headers: () => ({ "X-CSRFToken": csrfToken() }), // optional, per request
    notify: (message, kind) => yourSnackbar.show(message, kind), // optional
  }),
);

router.addRoute({ path: "/marketplace", component: YourLayout, children: marketplaceRoutes() });
```

In your layout:

```vue
<script setup lang="ts">
import { marketplaceNavigation, MarketplaceNotifier, NotificationBell } from "@realhrsoft/marketplace-employee";
</script>

<template>
  <v-app-bar>
    …your company switcher…
    <NotificationBell />
  </v-app-bar>
  <v-navigation-drawer>
    <v-list nav>
      <v-list-item v-for="item in marketplaceNavigation" :key="item.title" :to="item.to" :prepend-icon="item.icon" :title="item.title" />
    </v-list>
  </v-navigation-drawer>
  <v-main><router-view /></v-main>
  <!-- Only when you do not pass `notify`: -->
  <MarketplaceNotifier />
</template>
```

Screens link to each other by route name (`ROUTE`), so you can mount the routes under any
path. The default is `/marketplace`.

### Options

| Option | Required | Meaning |
| --- | --- | --- |
| `baseUrl` | yes | Same-origin path of your proxy for the Marketplace API. |
| `companyId` | yes | Ref or getter with the RealHRSoft company UUID the employee acts for, or `null`. Browsing, benefits and claiming show "Choose your company" while it is `null`. |
| `headers` | no | Extra headers per request, such as CSRF. May be async. |
| `credentials` | no | Fetch credentials mode for the proxy (default `include`, which sends your session cookie). |
| `fetch` | no | Replaces `fetch`; it receives a `Request`. |
| `notify` | no | Your notifier for confirmations and warnings. Without it, mount `<MarketplaceNotifier />`. |

### Company selection

An employee can be employed by several companies of one group. The Marketplace needs to know
which one they act for, because offers, benefits and use limits are evaluated per company.
Your app already knows the employee's companies, so it owns the switcher and passes the
selected UUID as `companyId`.

## 2. The backend proxy (required)

Employees never hold a Marketplace token in the browser. Your backend authenticates the
employee with its own session and forwards each request to the Marketplace with a freshly
signed employee token:

```
Browser  ──>  GET  /api/marketplace/marketplace/offers   (your session cookie, X-Company-ID)
Your backend  ──>  GET  {MARKETPLACE}/api/v1/marketplace/offers
                       Authorization: Bearer <employee token>
                       X-Company-ID, X-Request-ID, Idempotency-Key, Content-Type (forwarded)
```

- **Map paths:** `{baseUrl}/x` goes to `{MARKETPLACE}/api/v1/x`. The screens only call
  `/marketplace/*` and `/me/notifications*`; refuse anything else.
- **Forward request headers:** `X-Company-ID`, `X-Request-ID`, `Idempotency-Key`,
  `Content-Type` and `Accept`. Drop the browser's cookies and `Authorization`.
- **Return the response unchanged:** status, body and `Content-Type`. Errors are RFC 7807
  Problem Details with a stable `code`, which the screens branch on. Advertisement images are
  binary.
- **Sign one token per request, or reuse one for at most its lifetime.** Before signing, check
  that the employee is active and still employed in the companies you assert.

### Employee token (RS256 JWT)

| Claim | Value |
| --- | --- |
| `iss` | Your configured issuer. |
| `aud` | The Marketplace audience (default `realhrsoft-marketplace`). |
| `sub` | The employee's RealHRSoft UUID. |
| `scope` | `marketplace.employee` |
| `jti` | A new UUID per token. |
| `iat`, `nbf`, `exp` | Now, now, and at most now + 60 s. |
| `partner_uuid` | The employee's client (group) UUID. |
| `company_uuids` | The companies the employee is currently employed by, under that client. |
| `authorization_revision` | The employee snapshot revision you last delivered to the Marketplace. |

The header carries `kid`. Publish the public keys (JWKS) at the URL the Marketplace is
configured with. Former employees cannot authenticate, so do not sign tokens for them. Their
history stays in the Marketplace, and returns if you activate them again.

### Responses the screens expect

Handled with their own behaviour or text:

- `403 EMPLOYEE_NOT_AUTHORIZED`: explains that the employee is not employed by the selected
  company.
- `409 ALREADY_CLAIMED`: opens the existing claim.
- `409 OFFER_VERSION_CHANGED`: shows the new terms to read again.
- `409 AD_CREATIVE_CHANGED`: reloads the advertisement.

Shown with the Marketplace's own message and a retry button:

- `409 AUTHORIZATION_SYNC_PENDING`: your newest snapshot has not been applied yet; it clears
  once applied.
- `409 AUTHORIZATION_CONTEXT_CHANGED`: the token predates the employee's current revision;
  your proxy should sign a new one, and can retry once on its own.
- `503 FEATURE_DISABLED`: employee access is switched off in the Marketplace.

## 3. Behaviour worth knowing

- **Claims and benefit uses** send an `Idempotency-Key` per attempt. A retry of the same
  attempt (for example, after a lost response) never claims twice. Your proxy must forward the
  header.
- **Voucher QR codes** are bearer secrets for a few minutes. They are held in component state
  only, never stored or logged, and disappear when they expire, when the voucher is used or
  when the employee hides them. Do not log response bodies of
  `POST /marketplace/vouchers/{id}/credential` in your proxy.
- **Offer and benefit texts** are Markdown written by businesses. They are rendered and
  sanitized: no scripts, styles or non-http(s) links.
- **Notifications** poll the unread count every 30 seconds while the tab is visible.
- **Sponsored content** is always labelled "Sponsored". Impressions are counted when at least
  half of an advertisement is visible; clicks follow only the links the Marketplace returns.
- **Theming** uses your Vuetify theme (`primary`, `secondary`, `success`, `warning`, `error`,
  `info`).

## 4. Local development

`npm run dev` starts a demo host app at http://localhost:5175. Its dev server plays your
backend proxy and signs tokens with the Marketplace's development command.

1. In the Marketplace backend (DEBUG on), create a key outside any repository:
   `poetry run python manage.py realhrsoft_dev_token keygen --out ~/.realhrsoft-dev-key.pem`.
   Add the printed `REALHRSOFT_ISSUER` and `REALHRSOFT_JWKS` to the backend's `.env`, then
   restart it.
2. Copy `demo/.env.example` to `demo/.env.local` and fill it in: the key path, a synchronized
   employee's RealHRSoft UUID (the demo seed has some), and their company UUIDs.
3. `npm install`, then `npm run dev`.

The proxy defaults to the sibling `../realhrsoft-marketplace-rest-api` backend. Override
`MARKETPLACE_BACKEND_DIR` in `demo/.env.local` if yours lives elsewhere; relative paths are
resolved from the Vue project root. `DEV_SIGNING_KEY` and `DEV_EMPLOYEE_ID` are required.
Restart the dev server after changing the environment file.

Other commands:

| Command | Purpose |
| --- | --- |
| `npm run build` | Package build into `dist/`, with type declarations. |
| `npm run type-check` | vue-tsc over the package, demo and tests. |
| `npm test` | Vitest with jsdom. |
| `npm run api:generate -- --pull` | Refresh `openapi/employee.json` and `src/api/schema.ts` from a running Marketplace (`OPENAPI_URL` overrides the default local URL). |

The Makefile wraps these (`make help`). `make check` runs what CI runs: type-check, tests,
`make api-check` (`src/api/schema.ts` matches `openapi/employee.json`) and the package
build. CI is `.github/workflows/ci.yml`; it takes effect once this package is in a GitHub
repository.
